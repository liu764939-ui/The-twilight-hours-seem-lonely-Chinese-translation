package com.example.application;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // --- 导航与视图 ---
    private LinearLayout navHome, navEngine, navSettings;
    private ScrollView pageHome, pageEngine, pageSettings;

    // --- 引擎权限 ---
    private TextView accStatusTxt, overlayStatusTxt, captureStatusTxt;
    private Button accActionBtn, overlayActionBtn, captureActionBtn;

    // --- AI 配置 ---
    private TextView urlTv, keyTv, modelStatusText;
    private Spinner modelSpinner;
    private ArrayAdapter<String> modelAdapter;
    private ArrayList<String> modelList = new ArrayList<String>();
    private ProgressBar loadingBar;

    // --- 常量 ---
    public static final String PREFS_NAME = "AIDE_PRO_CONFIG";
    public static final String KEY_VENDOR_URL = "vendor_url_0";
    public static final String KEY_VENDOR_KEY = "vendor_key_0";
    public static final String KEY_SELECTED_MODEL = "selected_model";
    private static final String GAME_PKG = "com.espero.oumagadoki";
    private static final String MT_PKG_NORMAL = "bin.mt.plus";
    private static final String MT_PKG_COEXIST = "bin.mt.plus2";
    private static final int REQ_CAPTURE = 1001;

    private SharedPreferences prefs;
    private String currentUrl, currentKey;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 彻底放开 Android 7.0+ 严格模式，确保安装意图不出错
        if (Build.VERSION.SDK_INT >= 24) {
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        }

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        currentUrl = prefs.getString(KEY_VENDOR_URL, "http://localhost:11434/v1");
        currentKey = prefs.getString(KEY_VENDOR_KEY, "");

        initUI();
    }

    @Override
    protected void onResume() { super.onResume(); refreshEngineStatus(); }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_CAPTURE) {
            Toast.makeText(this, res == RESULT_OK ? "✅ 截屏授权成功" : "❌ 授权被拒绝", Toast.LENGTH_SHORT).show();
            if (res == RESULT_OK) {
                // 将截屏权限交给真正的底层引擎
                MyMediaProjection.getInstance(this).setData(res, data);
            }
            refreshEngineStatus();
        }
    }

    // ==================== UI 构建 ====================
    private void initUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F6F8FA"));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setBackgroundColor(Color.WHITE);
        topBar.setPadding(40, 40, 40, 30);
        TextView title = new TextView(this);
        title.setText("⛩️ 逢魔時 智能管家");
        title.setTextSize(22); title.setTypeface(null, Typeface.BOLD);
        topBar.addView(title);
        root.addView(topBar);

        FrameLayout content = new FrameLayout(this);
        content.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        pageHome = createHomePage();
        pageEngine = createEnginePage();
        pageSettings = createSettingsPage();
        content.addView(pageHome); content.addView(pageEngine); content.addView(pageSettings);
        root.addView(content);

        LinearLayout bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setBackgroundColor(Color.WHITE);
        navHome = createNavTab("📦\n部署", bottomNav);
        navEngine = createNavTab("🎮\n引擎", bottomNav);
        navSettings = createNavTab("🤖\nAI配置", bottomNav);
        root.addView(bottomNav);
        setContentView(root);

        navHome.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab(0); } });
        navEngine.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab(1); } });
        navSettings.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab(2); } });
        switchTab(0);
    }

    private LinearLayout createNavTab(String label, LinearLayout parent) {
        LinearLayout tab = new LinearLayout(this);
        tab.setOrientation(LinearLayout.VERTICAL); tab.setPadding(0,12,0,12);
        tab.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView tv = new TextView(this); tv.setText(label); tv.setGravity(Gravity.CENTER); tv.setTextSize(12);
        tab.addView(tv); parent.addView(tab); return tab;
    }

    private void switchTab(int idx) {
        pageHome.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        pageEngine.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        ((TextView)navHome.getChildAt(0)).setTextColor(Color.parseColor(idx==0?"#0366D6":"#586069"));
        ((TextView)navEngine.getChildAt(0)).setTextColor(Color.parseColor(idx==1?"#0366D6":"#586069"));
        ((TextView)navSettings.getChildAt(0)).setTextColor(Color.parseColor(idx==2?"#0366D6":"#586069"));
    }

    // ==================== 页面 1: 部署 ====================
    private ScrollView createHomePage() {
        ScrollView scroll = new ScrollView(this); scroll.setPadding(20,20,20,20);
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);

        c.addView(title("📦 数据部署"));
        final Button deployBtn = btn("📥 一键安装APK与释放数据包", "#2EA44F", new View.OnClickListener() {
				@Override public void onClick(View v) {
					final Button btn = (Button)v;
					btn.setEnabled(false); btn.setText("⏳ 解压中，请稍候...");

					new Thread(new Runnable() {
							@Override public void run() {
								final String errMsg = extractAssetsToPrivateDir();
								mainHandler.post(new Runnable() {
										@Override public void run() {
											btn.setEnabled(true); btn.setText("📥 一键安装APK与释放数据包");
											if(errMsg == null) Toast.makeText(MainActivity.this, "✅ 释放成功！请安装游戏。", Toast.LENGTH_LONG).show();
											else {
												Toast.makeText(MainActivity.this, "❌ 失败: " + errMsg, Toast.LENGTH_LONG).show();
												showErrorDialog(errMsg);
											}
										}
									});
							}
						}).start();
				}
			});
        c.addView(card(deployBtn));

        c.addView(title("🚀 快速启动"));
        c.addView(card(btn("🎮 启动游戏", "#0366D6", new View.OnClickListener() {
							   @Override public void onClick(View v) { launchPkg(GAME_PKG); }
						   })));
        c.addView(card(btn("📁 打开 MT 管理器", "#6F42C1", new View.OnClickListener() {
							   @Override public void onClick(View v) {
								   if(isPkgInstalled(MT_PKG_NORMAL)) launchPkg(MT_PKG_NORMAL);
								   else if(isPkgInstalled(MT_PKG_COEXIST)) launchPkg(MT_PKG_COEXIST);
								   else Toast.makeText(MainActivity.this, "未安装 MT 管理器", Toast.LENGTH_SHORT).show();
							   }
						   })));
        scroll.addView(c); return scroll;
    }

    // 核心修改：释放到私有目录，彻底告别权限问题！
    // 核心修改：释放到私有目录，并加上 "Game/" 路径前缀
	private String extractAssetsToPrivateDir() {
		try {
			File privDir = getExternalFilesDir(null); // Android/data/包名/files/
			if (privDir == null) return "无法获取存储目录";

			File gameDataDir = new File(privDir, "逢魔时数据包");
			if (!gameDataDir.exists()) gameDataDir.mkdirs();

			// 1. 释放 OBB 和 Json (从 assets/Game/ 读取)
			String[] dataFiles = {"main.7.com.espero.oumagadoki.obb", "manifest.json"};
			for (String f : dataFiles) {
				// 读取时加上 "Game/" 前缀，写入时只用文件名 f
				copyAsset("Game/" + f, new File(gameDataDir, f));
			}

			// 2. 释放 APK 并拉起安装 (从 assets/Game/ 读取)
			final File apkFile = new File(privDir, "com.espero.oumagadoki.apk");
			copyAsset("Game/com.espero.oumagadoki.apk", apkFile);

			mainHandler.post(new Runnable() {
					@Override public void run() { installApk(apkFile); }
				});

			return null; // 成功返回 null
		} catch (Exception e) {
			e.printStackTrace();
			return e.toString();
		}
	}
	
    private void copyAsset(String assetName, File outFile) throws Exception {
        InputStream is = getAssets().open(assetName);
        FileOutputStream fos = new FileOutputStream(outFile);
        byte[] buf = new byte[8192]; int len;
        while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
        fos.flush(); fos.close(); is.close();
    }

    private void installApk(File apkFile) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive");
        try { startActivity(intent); } 
        catch (Exception e) { Toast.makeText(this, "拉起安装界面失败: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void showErrorDialog(String msg) {
        new AlertDialog.Builder(this)
            .setTitle("报错详情")
            .setMessage(msg)
            .setPositiveButton("确定", null)
            .show();
    }

    // ==================== 页面 2: 引擎 ====================
    private ScrollView createEnginePage() {
        ScrollView scroll = new ScrollView(this); scroll.setPadding(20,20,20,20);
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);

        c.addView(title("⚙️ 核心权限"));
        LinearLayout pCard = new LinearLayout(this); pCard.setOrientation(LinearLayout.VERTICAL);
        accStatusTxt=new TextView(this); accActionBtn=new Button(this);
        accActionBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } });
        pCard.addView(permRow("♿ 无障碍服务 (承载悬浮窗)", accStatusTxt, accActionBtn));

        overlayStatusTxt=new TextView(this); overlayActionBtn=new Button(this);
        overlayActionBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); } });
        pCard.addView(permRow("🪟 悬浮窗权限", overlayStatusTxt, overlayActionBtn));

        captureStatusTxt=new TextView(this); captureActionBtn=new Button(this);
        captureActionBtn.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
					if (mpm != null) startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
				}
			});
        pCard.addView(permRow("📸 屏幕截取", captureStatusTxt, captureActionBtn));
        c.addView(card(pCard));

        c.addView(title("🎯 引擎控制"));
        c.addView(card(btn("▶️ 唤起悬浮窗并打开游戏", "#28A745", new View.OnClickListener() {
							   @Override public void onClick(View v) {
								   if(isAccEnabled()) {
									   Toast.makeText(MainActivity.this, "✅ 服务已运行，正在唤起游戏...", Toast.LENGTH_SHORT).show();
									   launchPkg(GAME_PKG);
								   } else {
									   Toast.makeText(MainActivity.this, "⚠️ 悬浮窗寄宿在无障碍服务中，请先开启！", Toast.LENGTH_LONG).show();
									   startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
								   }
							   }
						   })));
        scroll.addView(c); return scroll;
    }

    private void refreshEngineStatus() {
        if(accStatusTxt==null) return;
        boolean accOk = isAccEnabled();
        accStatusTxt.setText(accOk?"🟢 开启":"🔴 关闭"); accActionBtn.setVisibility(accOk?View.GONE:View.VISIBLE);
        boolean ovOk = Build.VERSION.SDK_INT<23 || Settings.canDrawOverlays(this);
        overlayStatusTxt.setText(ovOk?"🟢 开启":"🔴 关闭"); overlayActionBtn.setVisibility(ovOk?View.GONE:View.VISIBLE);
        captureStatusTxt.setText("⚪ 点击授权");
    }

    private boolean isAccEnabled() {
        try {
            int en = Settings.Secure.getInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (en==0) return false;
            String list = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return list!=null && list.contains(getPackageName());
        } catch(Exception e){ return false; }
    }

    // ==================== 页面 3: AI配置 ====================
    private ScrollView createSettingsPage() {
        ScrollView scroll = new ScrollView(this); scroll.setPadding(20,20,20,20);
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);

        c.addView(title("🏭 API 节点配置"));
        LinearLayout vCard = new LinearLayout(this); vCard.setOrientation(LinearLayout.VERTICAL);
        urlTv = new TextView(this); urlTv.setText("URL: " + currentUrl);
        keyTv = new TextView(this); keyTv.setText("KEY: " + (currentKey.isEmpty()?"(未配置)":"********"));
        vCard.addView(urlTv); vCard.addView(keyTv);
        vCard.addView(btn("✏️ 修改节点", "#2EA44F", new View.OnClickListener() {
							  @Override public void onClick(View v) { showEditDialog(); }
						  }));
        c.addView(card(vCard));

        c.addView(title("🧠 模型分类与选择"));
        LinearLayout mCard = new LinearLayout(this); mCard.setOrientation(LinearLayout.VERTICAL);
        modelList.add(prefs.getString(KEY_SELECTED_MODEL, "— 未选择 —"));
        modelAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, modelList);
        modelSpinner = new Spinner(this); modelSpinner.setAdapter(modelAdapter);
        modelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				@Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
					String sel = modelList.get(pos);
					if(!sel.startsWith("—")) { prefs.edit().putString(KEY_SELECTED_MODEL, sel).apply(); Toast.makeText(MainActivity.this,"已选: "+sel,0).show();}
				}
				@Override public void onNothingSelected(AdapterView<?> p) {}
			});
        loadingBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); loadingBar.setVisibility(View.GONE);
        modelStatusText = new TextView(this);
        mCard.addView(modelSpinner); mCard.addView(loadingBar); mCard.addView(modelStatusText);
        mCard.addView(btn("🔄 抓取并分类模型", "#0366D6", new View.OnClickListener() {
							  @Override public void onClick(View v) { fetchModels(); }
						  }));
        c.addView(card(mCard));
		c.addView(title("🎯 引擎控制"));
		c.addView(card(btn("▶️ 唤起悬浮窗并打开游戏", "#28A745", new View.OnClickListener() {
							   @Override public void onClick(View v) {
								   if(isAccEnabled()) {
									   Toast.makeText(MainActivity.this, "✅ 正在强行唤起悬浮窗与游戏...", Toast.LENGTH_SHORT).show();
									   // 👇 加上这一行：发射强制弹窗的终极广播信号！
									   sendBroadcast(new Intent("ACTION_FORCE_SHOW_OVERLAY"));

									   launchPkg(GAME_PKG);
								   } else {
									   Toast.makeText(MainActivity.this, "⚠️ 悬浮窗寄宿在无障碍服务中，请先开启！", Toast.LENGTH_LONG).show();
									   startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
								   }
							   }
						   })));

        scroll.addView(c); return scroll;
    }

    private void showEditDialog() {
        AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_Holo_Light_Dialog);
        b.setTitle("API 节点设置");
        LinearLayout f = new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(40,20,40,20);
        final EditText uIn = new EditText(this); uIn.setText(currentUrl); uIn.setHint("http://...");
        final EditText kIn = new EditText(this); kIn.setText(currentKey); kIn.setHint("API Key (可选)"); kIn.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        f.addView(uIn); f.addView(kIn); b.setView(f);
        b.setPositiveButton("保存", new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int w) {
					currentUrl=uIn.getText().toString().trim(); currentKey=kIn.getText().toString().trim();
					prefs.edit().putString(KEY_VENDOR_URL, currentUrl).putString(KEY_VENDOR_KEY, currentKey).apply();
					urlTv.setText("URL: "+currentUrl); keyTv.setText("KEY: "+(currentKey.isEmpty()?"未配置":"********"));
				}
			});
        b.show();
    }

    private void fetchModels() {
        loadingBar.setVisibility(View.VISIBLE); loadingBar.setIndeterminate(true); modelStatusText.setText("获取中...");
        new Thread(new Runnable() {
				@Override public void run() {
					try {
						URL u = new URL(currentUrl.replaceAll("/+$", "") + "/models");
						HttpURLConnection conn = (HttpURLConnection) u.openConnection();
						conn.setRequestProperty("Authorization", "Bearer " + (currentKey.isEmpty()?"none":currentKey));
						conn.setConnectTimeout(8000);
						if (conn.getResponseCode() == 200) {
							BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
							StringBuilder sb = new StringBuilder(); String line;
							while((line=br.readLine())!=null) sb.append(line);
							JSONObject root = new JSONObject(sb.toString());
							final List<String> raw = new ArrayList<String>();
							JSONArray data = root.optJSONArray("data"); if(data==null) data=root.optJSONArray("models");
							if(data!=null) {
								for(int i=0;i<data.length();i++) {
									String id = data.getJSONObject(i).optString("id", data.getJSONObject(i).optString("name",""));
									if(!id.isEmpty()) raw.add(id);
								}
							}
							mainHandler.post(new Runnable() {
									@Override public void run() {
										modelList.clear(); modelList.addAll(categorize(raw));
										modelAdapter.notifyDataSetChanged();
										modelStatusText.setText("✅ 获取到 " + raw.size() + " 个模型"); loadingBar.setVisibility(View.GONE);
									}
								});
						} else throw new Exception("HTTP "+conn.getResponseCode());
					} catch (final Exception e) {
						mainHandler.post(new Runnable() { @Override public void run() { modelStatusText.setText("❌ 失败: "+e.getMessage()); loadingBar.setVisibility(View.GONE); } });
					}
				}
			}).start();
    }

    private List<String> categorize(List<String> raw) {
        List<String> ds=new ArrayList<String>(), qwen=new ArrayList<String>(), oai=new ArrayList<String>(), oth=new ArrayList<String>();
        for(String m : raw) {
            String l = m.toLowerCase();
            if(l.contains("deepseek")) ds.add(m); else if(l.contains("qwen")) qwen.add(m); else if(l.contains("gpt")||l.contains("o1")) oai.add(m); else oth.add(m);
        }
        List<String> res = new ArrayList<String>();
        if(!ds.isEmpty()) {res.add("— 🔵 DeepSeek —"); res.addAll(ds);}
        if(!oai.isEmpty()) {res.add("— 🟢 OpenAI —"); res.addAll(oai);}
        if(!qwen.isEmpty()) {res.add("— 🟣 Qwen —"); res.addAll(qwen);}
        if(!oth.isEmpty()) {res.add("— ⚪ Other —"); res.addAll(oth);}
        return res;
    }

    // ==================== UI 工具集 ====================
    private TextView title(String t) { TextView v=new TextView(this); v.setText(t); v.setTextSize(16); v.setTypeface(null, Typeface.BOLD); v.setPadding(0,20,0,10); return v; }
    private LinearLayout card(View v) { LinearLayout c=new LinearLayout(this); c.setPadding(30,30,30,30); GradientDrawable d=new GradientDrawable(); d.setColor(Color.WHITE); d.setCornerRadius(16); c.setBackground(d); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,20); c.setLayoutParams(p); if(v!=null) c.addView(v); return c; }
    private Button btn(String t, String clr, View.OnClickListener l) { Button b=new Button(this); b.setText(t); b.setTextColor(Color.WHITE); GradientDrawable d=new GradientDrawable(); d.setColor(Color.parseColor(clr)); d.setCornerRadius(8); b.setBackground(d); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,10,0,10); b.setLayoutParams(p); b.setOnClickListener(l); return b; }
    private LinearLayout permRow(String txt, TextView st, Button a) { LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); TextView t=new TextView(this); t.setText(txt); r.addView(t); r.addView(st); a.setText("去授权"); r.addView(a); return r; }

    private void launchPkg(String p) { try { startActivity(getPackageManager().getLaunchIntentForPackage(p)); } catch(Exception e){} }
    private boolean isPkgInstalled(String p) { try{ getPackageManager().getPackageInfo(p,0); return true; }catch(Exception e){ return false; } }
}
