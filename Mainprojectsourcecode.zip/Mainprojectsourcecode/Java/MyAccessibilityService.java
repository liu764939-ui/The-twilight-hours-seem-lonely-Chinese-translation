package com.example.application;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MyAccessibilityService extends AccessibilityService {

    private WindowManager wm;
    private View ballView;
    private WindowManager.LayoutParams ballParams;

    private LinearLayout boxView;
    private WindowManager.LayoutParams boxParams;
    private LinearLayout toolbar;
    private FrameLayout captureArea;
    private TextView resultText;
    private GradientDrawable border;

    private boolean isTranslating = false;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            createBall();
            createBox();
        }
    }

    private void createBall() {
        ballView = new FrameLayout(this);
        TextView tv = new TextView(this);
        tv.setText("译");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(18);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor("#1296db"));
        bg.setStroke(4, Color.WHITE);
        tv.setBackgroundDrawable(bg);
        ((FrameLayout)ballView).addView(tv, new FrameLayout.LayoutParams(140, 140));

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        ballParams = new WindowManager.LayoutParams(140, 140, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        ballParams.gravity = Gravity.TOP | Gravity.LEFT;
        ballParams.x = 20; ballParams.y = 200;

        ballView.setOnTouchListener(new View.OnTouchListener() {
				int ix, iy; float tx, ty; boolean moved;
				@Override public boolean onTouch(View v, MotionEvent e) {
					switch (e.getAction()) {
						case MotionEvent.ACTION_DOWN:
							ix=ballParams.x; iy=ballParams.y; tx=e.getRawX(); ty=e.getRawY(); moved=false; return true;
						case MotionEvent.ACTION_MOVE:
							if(Math.abs(e.getRawX()-tx)>20 || Math.abs(e.getRawY()-ty)>20) moved=true;
							ballParams.x = ix + (int)(e.getRawX()-tx); ballParams.y = iy + (int)(e.getRawY()-ty);
							wm.updateViewLayout(ballView, ballParams); return true;
						case MotionEvent.ACTION_UP:
							if(!moved) toggleBox();
							return true;
					}
					return false;
				}
			});
        wm.addView(ballView, ballParams);
    }

    private void createBox() {
        boxView = new LinearLayout(this);
        boxView.setOrientation(LinearLayout.VERTICAL);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        boxParams = new WindowManager.LayoutParams(800, 400, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        boxParams.gravity = Gravity.TOP | Gravity.LEFT;
        boxParams.x = 100; boxParams.y = 800;

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setBackgroundColor(Color.parseColor("#DD000000"));
        toolbar.setGravity(Gravity.CENTER_VERTICAL);

        TextView dragBtn = new TextView(this);
        dragBtn.setText("✋ 拖动"); dragBtn.setTextColor(Color.WHITE); dragBtn.setPadding(20, 20, 20, 20);
        toolbar.addView(dragBtn, new LinearLayout.LayoutParams(0, -2, 1.0f));

        Button transBtn = new Button(this);
        transBtn.setText("▶ 自动翻译"); transBtn.setTextColor(Color.WHITE); transBtn.setBackgroundColor(Color.parseColor("#E91E63"));
        toolbar.addView(transBtn, new LinearLayout.LayoutParams(-2, -2));

        TextView resizeBtn = new TextView(this);
        resizeBtn.setText("↘ 缩放"); resizeBtn.setTextColor(Color.WHITE); resizeBtn.setPadding(20, 20, 20, 20);
        toolbar.addView(resizeBtn, new LinearLayout.LayoutParams(-2, -2));

        boxView.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));

        captureArea = new FrameLayout(this);
        border = new GradientDrawable();
        border.setStroke(6, Color.RED);
        border.setColor(Color.parseColor("#33000000"));
        captureArea.setBackgroundDrawable(border);

        resultText = new TextView(this);
        resultText.setTextColor(Color.WHITE);
        resultText.setTextSize(20);
        resultText.setTypeface(null, Typeface.BOLD);
        resultText.setPadding(20, 20, 20, 20);
        resultText.setShadowLayer(8f, 2f, 2f, Color.BLACK); 
        resultText.setVisibility(View.GONE);
        captureArea.addView(resultText, new FrameLayout.LayoutParams(-1, -1));

        boxView.addView(captureArea, new LinearLayout.LayoutParams(-1, -1));

        dragBtn.setOnTouchListener(new View.OnTouchListener() {
				int ix, iy; float tx, ty;
				@Override public boolean onTouch(View v, MotionEvent e) {
					if (isTranslating) return false;
					switch (e.getAction()) {
						case MotionEvent.ACTION_DOWN:
							ix = boxParams.x; iy = boxParams.y; tx = e.getRawX(); ty = e.getRawY(); return true;
						case MotionEvent.ACTION_MOVE:
							boxParams.x = ix + (int)(e.getRawX() - tx); boxParams.y = iy + (int)(e.getRawY() - ty);
							wm.updateViewLayout(boxView, boxParams); return true;
					}
					return false;
				}
			});

        resizeBtn.setOnTouchListener(new View.OnTouchListener() {
				int iw, ih; float tx, ty;
				@Override public boolean onTouch(View v, MotionEvent e) {
					if (isTranslating) return false;
					switch (e.getAction()) {
						case MotionEvent.ACTION_DOWN:
							iw = boxParams.width; ih = boxParams.height; tx = e.getRawX(); ty = e.getRawY(); return true;
						case MotionEvent.ACTION_MOVE:
							boxParams.width = Math.max(300, iw + (int)(e.getRawX() - tx));
							boxParams.height = Math.max(200, ih + (int)(e.getRawY() - ty));
							wm.updateViewLayout(boxView, boxParams); return true;
					}
					return false;
				}
			});

        transBtn.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { startAutoTranslate(); }
			});

        boxView.setVisibility(View.GONE);
        wm.addView(boxView, boxParams);
    }

    private void toggleBox() {
        if (boxView.getVisibility() == View.GONE) {
            boxView.setVisibility(View.VISIBLE);
            resetBoxToEditMode();
        } else {
            if (isTranslating) {
                MyMediaProjection.getInstance(this).stopAutoCapture();
                resetBoxToEditMode();
            } else {
                boxView.setVisibility(View.GONE);
            }
        }
    }

    private void resetBoxToEditMode() {
        isTranslating = false;
        toolbar.setVisibility(View.VISIBLE); 
        captureArea.setBackgroundDrawable(border); 
        resultText.setVisibility(View.GONE); 

        boxParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(boxView, boxParams);
    }

    private void startAutoTranslate() {
        int[] loc = new int[2];
        captureArea.getLocationOnScreen(loc);
        final Rect crop = new Rect(loc[0], loc[1], loc[0] + captureArea.getWidth(), loc[1] + captureArea.getHeight());

        isTranslating = true;
        toolbar.setVisibility(View.GONE); 
        captureArea.setBackgroundColor(Color.parseColor("#B3000000")); // 改成沉浸式黑底

        resultText.setText("👁️ 正在监听画面变动...");
        resultText.setVisibility(View.VISIBLE);

        // 🔥 神奇穿透：你的手指可以直接点透这行字，去点游戏！
        boxParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(boxView, boxParams);

        MyMediaProjection.getInstance(this).startAutoCapture(crop, new MyMediaProjection.TextCallback() {
				@Override public void onSuccess(String text) {
					resultText.setText(text);
				}
				@Override public void onError(String err) {
					resultText.setText(err);
				}
			});
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public boolean onUnbind(Intent intent) {
        if(ballView!=null) wm.removeView(ballView);
        if(boxView!=null) wm.removeView(boxView);
        return super.onUnbind(intent);
    }
}
