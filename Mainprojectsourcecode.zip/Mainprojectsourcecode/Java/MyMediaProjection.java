package com.example.application;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;

public class MyMediaProjection {

    private static MyMediaProjection instance;
    private Context context;
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Intent resultData;
    private int resultCode;

    private int screenWidth, screenHeight, screenDensity;

    private HandlerThread handlerThread;
    private Handler backgroundHandler;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private boolean isAutoRunning = false;
    private Bitmap lastTranslatedBitmap = null;
    private Bitmap previousFrame = null;
    private int stableCounter = 0;

    private static final String PREFS_NAME = "AIDE_PRO_CONFIG";
    private static final String KEY_VENDOR_URL = "vendor_url_0";
    private static final String KEY_VENDOR_KEY = "vendor_key_0";
    private static final String KEY_SELECTED_MODEL = "selected_model";

    public interface TextCallback {
        void onSuccess(String text);
        void onError(String errorMsg);
    }

    private MyMediaProjection(Context context) {
        this.context = context.getApplicationContext();
        projectionManager = (MediaProjectionManager) this.context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        handlerThread = new HandlerThread("ScreenCaptureThread");
        handlerThread.start();
        backgroundHandler = new Handler(handlerThread.getLooper());
    }

    public static MyMediaProjection getInstance(Context context) {
        if (instance == null) instance = new MyMediaProjection(context);
        return instance;
    }

    public void setData(int resultCode, Intent resultData) {
        this.resultCode = resultCode;
        this.resultData = resultData;
    }

    private void postError(final TextCallback callback, final String msg) {
        mainHandler.post(new Runnable() { @Override public void run() { callback.onError(msg); } });
    }

    // 🔥 核心：动态适应横竖屏切换
    private boolean updateMetrics() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        int cw = metrics.widthPixels;
        int ch = metrics.heightPixels;

        if (imageReader == null || cw != screenWidth || ch != screenHeight) {
            screenWidth = cw; screenHeight = ch; screenDensity = metrics.densityDpi;
            if (virtualDisplay != null) virtualDisplay.release();
            if (imageReader != null) imageReader.close();
            if (mediaProjection == null && resultData != null) {
                mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            }
            if (mediaProjection == null) return false;

            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
            virtualDisplay = mediaProjection.createVirtualDisplay("ScreenCapture", screenWidth, screenHeight, screenDensity,
																  DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, backgroundHandler);
        }
        return true;
    }

    public void stopAutoCapture() {
        isAutoRunning = false;
    }

    // 🚀 核心：全自动打字机感知循环
    public void startAutoCapture(final Rect cropRect, final TextCallback callback) {
        if (resultData == null) {
            postError(callback, "未获得截屏权限，请先在管家授权！"); return;
        }
        isAutoRunning = true;
        lastTranslatedBitmap = null;
        previousFrame = null;
        stableCounter = 0;

        runAutoLoop(cropRect, callback);
    }

    private void runAutoLoop(final Rect cropRect, final TextCallback callback) {
        if (!isAutoRunning) return;

        backgroundHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					if (!isAutoRunning) return;
					try {
						if (!updateMetrics()) {
							postError(callback, "截屏引擎未准备好"); return;
						}

						Image image = imageReader.acquireLatestImage();
						if (image != null) {
							Bitmap cropped = getCroppedBitmap(image, cropRect);
							image.close();

							if (cropped != null) {
								if (isBitmapSimilar(cropped, previousFrame)) {
									stableCounter++;
									// 画面静止了 1 秒（打字机出字完毕），并且是一句全新的话
									if (stableCounter >= 2 && !isBitmapSimilar(cropped, lastTranslatedBitmap)) {
										lastTranslatedBitmap = cropped;
										mainHandler.post(new Runnable() { @Override public void run() { callback.onSuccess("⏳ 翻译中..."); } });
										requestVisionAPI(cropped, callback);
									}
								} else {
									// 画面正在变动（游戏中正在逐字显示）
									stableCounter = 0;
									previousFrame = cropped;
								}
							}
						}
					} catch (Exception ignored) {}

					runAutoLoop(cropRect, callback);
				}
			}, 500); // 半秒扫一次，极度省电
    }

    private Bitmap getCroppedBitmap(Image image, Rect cropRect) {
        int width = image.getWidth(), height = image.getHeight();
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride(), rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;

        Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);

        int cx = Math.max(0, cropRect.left), cy = Math.max(0, cropRect.top);
        int cw = Math.min(width - cx, cropRect.width()), ch = Math.min(height - cy, cropRect.height());
        if(cw <= 0 || ch <= 0) return null;

        return Bitmap.createBitmap(bitmap, cx, cy, cw, ch);
    }

    // 毫秒级画面指纹对比技术（容忍呼吸光标）
    private boolean isBitmapSimilar(Bitmap b1, Bitmap b2) {
        if (b1 == null || b2 == null) return false;
        Bitmap s1 = Bitmap.createScaledBitmap(b1, 32, 32, true);
        Bitmap s2 = Bitmap.createScaledBitmap(b2, 32, 32, true);
        int diff = 0;
        int[] p1 = new int[1024]; int[] p2 = new int[1024];
        s1.getPixels(p1, 0, 32, 0, 0, 32, 32); s2.getPixels(p2, 0, 32, 0, 0, 32, 32);
        for (int i = 0; i < 1024; i++) {
            int c1 = p1[i], c2 = p2[i];
            if (Math.abs(Color.red(c1) - Color.red(c2)) + Math.abs(Color.green(c1) - Color.green(c2)) + Math.abs(Color.blue(c1) - Color.blue(c2)) > 30) {
                diff++;
            }
        }
        return diff < 50; // 小于5%的变化视为同一句话
    }

    private void requestVisionAPI(Bitmap croppedBitmap, final TextCallback callback) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String apiUrl = prefs.getString(KEY_VENDOR_URL, "");
        String apiKey = prefs.getString(KEY_VENDOR_KEY, "");
        String modelName = prefs.getString(KEY_SELECTED_MODEL, "");

        if (apiUrl.isEmpty() || modelName.isEmpty()) return;

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        croppedBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream);
        final String base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP);

        final String finalApiUrl = apiUrl.replaceAll("/+$", "") + "/chat/completions";
        final String finalApiKey = apiKey.isEmpty() ? "ollama" : apiKey;
        final String finalModel = modelName;

        new Thread(new Runnable() {
				@Override
				public void run() {
					HttpURLConnection conn = null;
					try {
						URL url = new URL(finalApiUrl);
						conn = (HttpURLConnection) url.openConnection();
						conn.setRequestMethod("POST");
						conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
						conn.setRequestProperty("Authorization", "Bearer " + finalApiKey);
						conn.setDoOutput(true); conn.setConnectTimeout(10000); conn.setReadTimeout(30000);

						JSONObject root = new JSONObject();
						root.put("model", finalModel); root.put("temperature", 0.1); 

						JSONArray messages = new JSONArray();
						JSONObject userMsg = new JSONObject(); userMsg.put("role", "user");
						JSONArray contentArr = new JSONArray();

						JSONObject textObj = new JSONObject(); textObj.put("type", "text");
						// 彻底杜绝 AI 报“没有文字”在屏幕上乱显示
						textObj.put("text", "提取图片中的日文文本并翻译成中文。请只输出中文翻译，严禁输出任何多余的解释！如果图片中没有字，请必须输出“EMPTY”这五个字母。");
						contentArr.put(textObj);

						JSONObject imageObj = new JSONObject(); imageObj.put("type", "image_url");
						JSONObject imageUrl = new JSONObject(); imageUrl.put("url", "data:image/jpeg;base64," + base64Image);
						imageObj.put("image_url", imageUrl); contentArr.put(imageObj);

						userMsg.put("content", contentArr); messages.put(userMsg); root.put("messages", messages);

						OutputStream os = conn.getOutputStream();
						os.write(root.toString().getBytes("UTF-8")); os.flush(); os.close();

						if (conn.getResponseCode() == 200) {
							BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
							StringBuilder response = new StringBuilder(); String line;
							while ((line = in.readLine()) != null) response.append(line);
							in.close();

							JSONObject jsonResp = new JSONObject(response.toString());
							final String translatedText = jsonResp.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();

							if (!translatedText.contains("EMPTY") && !translatedText.isEmpty()) {
								mainHandler.post(new Runnable() { @Override public void run() { callback.onSuccess(translatedText); } });
							}
						}
					} catch (Exception ignored) {} 
					finally { if (conn != null) conn.disconnect(); }
				}
			}).start();
    }
}
